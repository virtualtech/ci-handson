package jp.virtualtech.sample;

// StdLibs
import java.util.List;
import java.util.HashMap;
import java.util.Map;

// SpringBoot
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.beans.factory.annotation.Autowired;

// this
import jp.virtualtech.sample.repository.PostRepository;
import jp.virtualtech.sample.entity.Post;

@RestController
@EnableAutoConfiguration
public class APIController {
    @Autowired
    PostRepository postRepository;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public Map<String, String> healthCheck() {
        Map<String, String> ret = new HashMap<String, String>();
        ret.put("message", "hello, world");
        return ret;
    }

    @RequestMapping(value = "/post/list", method = RequestMethod.GET)
    public Map<String, Object> getPostList() {
        Map<String, Object> ret = new HashMap<String, Object>();
        List<Post> posts = postRepository.findAll();
        ret.put("posts", posts);
        return ret;
    }

    @RequestMapping(value = "/post/{post_id}", method = RequestMethod.GET)
    public Map<String, Object> getSpecificPost(@PathVariable("post_id") int id) {
        Map<String, Object> ret = new HashMap<String, Object>();
        Post post = postRepository.findOne(id);
        ret.put("post", post);
        return ret;
    }

    @RequestMapping(value = "/post", method = RequestMethod.POST, consumes = "application/json")
    public Map<String, Object> postNewPost(@RequestBody Post newPost) {
        Map<String, Object> ret = new HashMap<String, Object>();
        Post savedPost = postRepository.saveAndFlush(newPost);
        ret.put("post", savedPost);
        return ret;
    }

    /** Additional Feature */
    @RequestMapping(value = "/post/{post_id}/delete", method = RequestMethod.POST)
    public Map<String, Object> postDeletePost(@PathVariable("post_id") int id) {
        Map<String, Object> ret = new HashMap<String, Object>();
        postRepository.delete(id);

        ret.put("id", new Integer(id));
        ret.put("status", "deleted");
        return ret;
    }
    //*/
}
