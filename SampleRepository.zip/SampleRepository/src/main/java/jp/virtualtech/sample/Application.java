package jp.virtualtech.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class Application extends SpringBootServletInitializer {
    public static void main(String[] args) {
        SpringApplication.run(APIController.class, args);
    }

    @Override // implements SpringBootServletInitializer for Tomcat
    protected SpringApplicationBuilder configure(SpringApplicationBuilder app) {
        return app.sources(APIController.class);
    }
}
