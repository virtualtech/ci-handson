package jp.virtualtech.sample;

// JUnit
import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;

// SpringBoot
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.http.MediaType;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import jp.virtualtech.sample.entity.Post;
import jp.virtualtech.sample.repository.PostRepository;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=APIController.class)
@AutoConfigureMockMvc
public class APIControllerTest {
    @Autowired
    private PostRepository postRepository;

    @Autowired
    private MockMvc mockMvc;

    private Post testPost;

    private static int counter = 0;

    @Before
    public void setUp() {
        Post p = new Post("Taro", "HELLO");
        testPost = postRepository.saveAndFlush(p);
        counter++;

        System.out.println("\nsetUp");

        System.out.println(counter);
        System.out.println(postRepository.findAll());

    }

    @After
    public void tearDown() {
        System.out.println("tearDown");

        System.out.println(counter);
        System.out.println(postRepository.findAll());
        postRepository.delete(testPost);
    }

    @Test
    public void testGetHealthCheck() throws Exception {
        System.out.println("testGetHealthCheck");

        mockMvc.perform(get("/"))
            .andExpect(status().isOk())
            .andExpect(content().json("{'message':'hello, world'}"));
    }

    @Test
    public void testGetPostList() throws Exception {
        System.out.println("testGetPostList");

        mockMvc.perform(get("/post/list"))
            .andExpect(status().isOk())
            .andExpect(content().json("{'posts': [{'username': 'Taro', 'id': 1, 'body': 'HELLO'}]}"));
    }

    @Test
    public void testGetSpecificPost() throws Exception {
        System.out.println("testGetSpecificPost");

        mockMvc.perform(get("/post/" + Integer.toString(counter)))
            .andExpect(status().isOk())
            .andExpect(content().json("{'post': {'username': 'Taro', 'id': " + Integer.toString(counter) + ", 'body': 'HELLO'}}"));
    }

    @Test
    public void testPostNewPost() throws Exception {
        System.out.println("testPostNewPost");

        counter++;
        mockMvc.perform(post("/post")
                        .content("{\"username\":\"Geeko\", \"body\":\"Yes\"}")
                        .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(content().json("{'post': {'username': 'Geeko', 'body': 'Yes', 'id': " + Integer.toString(counter) + "}}"));
    }

    /** Additional Test */
    @Test public void testDeletePost() throws Exception {
        System.out.println("testDeletePost");

        mockMvc.perform(post("/post/" + Integer.toString(counter) + "/delete"))
            .andExpect(status().isOk())
            .andExpect(content().json("{'status': 'deleted', 'id': " + Integer.toString(counter) + "}"));
        counter++;
    }
    //*/
}
