package jp.virtualtech.sample.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import jp.virtualtech.sample.entity.Post;

public interface PostRepository extends JpaRepository<Post, Integer> {
}
